#!/bin/sh

pip install redis==2.10.5
python -u worker.py