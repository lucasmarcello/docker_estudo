\l
\c email_sender
\d emails